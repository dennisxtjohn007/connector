package com.alation.commomutilies;

public class Constants {
public static String USERNAME="vamsin@logandata.com";
public static String PASSWORD="Y@shvin$123";
public static String HOST="https://dm-us.informaticacloud.com/";
public static String HOSTNAME="svc_acc";
public static String HOSTPASSWORD="Logan2022";
public static String FOLDERNAME="Alation";
public static String websiteURL="http://44.207.25.64/instance/";
public static String MESSAGE=null;
public static String TITLE="August30";
public static int DELAY=6;
public static String DATASOURCENAME="Informatica - Testing QA Team";
public static int Duration=3000;
public static String DBTYPE="Informatica";
}
