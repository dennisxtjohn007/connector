package com.alation.commomutilies;
import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.io.FileHandler;
import org.openqa.selenium.support.PageFactory;
import org.testng.ITestResult;
import org.testng.annotations.BeforeGroups;
import org.testng.annotations.BeforeTest;

import com.alation.webpages.LoginPage;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;
public class WebEventListener {

	private static WebDriver driver;
	public static ExtentReports extent;
	public static ExtentTest logger;
	public WebEventListener(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	
	
	
	public void  highlight(WebElement ele) {
		String aString=ele.toString();
	
		((JavascriptExecutor) driver).executeScript("arguments[0].style.border='4px solid yellowgreen'", ele);
		//((JavascriptExecutor)driver).executeScript("arguments[0].setAttribute('style','background: peachpuff;');",elem);
		
	    }
	 public static String screenshot() throws IOException
	   {
		   DateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy HH-mm-ss");
		   Date dt = new Date();
		   String fileName;
		
		   fileName = driver.getTitle().toString().trim().replaceAll("[^a-zA-Z0-9]", "");
	     String  screenshotname=fileName+dateFormat.format(dt)+".png";
	       TakesScreenshot scr= ((TakesScreenshot)driver);
	       File file1= scr.getScreenshotAs(OutputType.FILE);
	       File dest=new File(System.getProperty("user.dir")+"//screenshots//"+screenshotname);
	       FileHandler.copy(file1,dest);
	      System.out.println("Screenshot of the test is taken");
	      return dest.getAbsolutePath();
	   }
	 public static String captureScreenshot() throws IOException
	   {
		  TakesScreenshot scr= ((TakesScreenshot)driver);
	      String base64code= scr.getScreenshotAs(OutputType.BASE64);
	      System.out.println("Screenshot of the test is taken");
	      return base64code;
	   }
	 
	}

