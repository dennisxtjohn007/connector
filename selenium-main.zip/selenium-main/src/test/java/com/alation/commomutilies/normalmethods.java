package com.alation.commomutilies;

import java.time.Duration;
import java.time.LocalTime;
import java.util.NoSuchElementException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.io.FileHandler;

import com.alation.commomutilies.Constants;
import java.time.LocalTime;
import com.alation.commomutilies.WebEventListener;

import com.alation.webpages.LoginPage;
import com.alation.webpages.SourcesPage;

import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.testng.annotations.AfterMethod;

import java.io.File;
import java.io.IOException;
import java.time.Duration;
import java.util.NoSuchElementException;

import org.apache.log4j.Logger;
import dev.failsafe.internal.util.Assert;
public class normalmethods {
	
	public static Logger log = Logger.getLogger(SourcesPage.class);

	public WebDriver driver;
	public WebEventListener listener;
	
	SourcesPage source=new SourcesPage(driver);
	
	public normalmethods(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
		 listener=new WebEventListener(driver);
		
	}
	
	public boolean waituptoactioncomplete() {
	boolean teststepstatus=false;
	LocalTime currentTime = LocalTime.now();
	LocalTime ExpectedTime = currentTime.plusSeconds(Constants.Duration);
	for(int i=0; i<100;i++) {
	LocalTime a = LocalTime.now();
	boolean x = a.isAfter(ExpectedTime);
	try{if(!x) {
	try {
	log.info("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
	source.Refresh_btn.click();
	driver.findElement((By) source.Status);
	log.info("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
	teststepstatus= true;
	log.info("Test Step Status"+teststepstatus);
	break;
	} catch (NoSuchElementException noSuchElement) {
	               
	try {
	log.info("+++++++++++++++++++++++++++++Polling Started++++++++++++++++++++++++++++++");
	new FluentWait<WebDriver>(driver).withTimeout(Duration.ofSeconds(150)).pollingEvery(Duration.ofMillis(10))
	.ignoring(NoSuchElementException.class)
	.until(ExpectedConditions.visibilityOfElementLocated( (By) source.Status));
	teststepstatus = true;
	log.info("Test Step Status"+teststepstatus);
	break;
	} catch (Exception ex) {
	}
 log.info(noSuchElement.toString());

	} catch (Exception e) {
	log.info(e.toString());
	}
	}
	else {

	}}catch(Exception ex) {


	}
	}
	return teststepstatus;
	}
}
