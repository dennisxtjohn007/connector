package com.alation.tests;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.Assert;
import org.testng.AssertJUnit;
import org.testng.ITestResult;

import com.alation.commomutilies.WebEventListener;
import com.alation.webpages.SourcesPage;
import com.alation.webpages.LoginPage;

import org.apache.logging.log4j.core.util.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.io.FileHandler;
import org.openqa.selenium.remote.ScreenshotException;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.TimeUnit;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.Markup;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.*;
import com.aventstack.extentreports.reporter.configuration.Theme;

@Run
public class Negitive_test {
	public WebEventListener listener;
	public ExtentReports extent;
	public ExtentTest logger;
	WebDriver driver;
	
	
	@BeforeClass
	public void setup(){
		System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir")+"\\drivers\\chromedriver.exe");
		ChromeOptions options=new ChromeOptions();
		options.setHeadless(false);
		driver=new ChromeDriver(options);
		driver.manage().window().maximize();
	
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		
	}


	@BeforeTest
	public void startReport() {
           DateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy HH-mm-ss");
		   Date dt = new Date();
		   String fileName;
		   fileName = "report";
	     String  reportname=fileName+dateFormat.format(dt)+".html";
	     extent = new ExtentReports();
		 ExtentSparkReporter spark = new ExtentSparkReporter(System.getProperty("user.dir")+"\\Reports\\"+reportname);
	     extent.attachReporter(spark);
	     logger=extent.createTest("Launching browser");
		 spark.config().setDocumentTitle("Smoke Testing");
            // Name of the report
      spark.config().setReportName("Testing informatica connectors in Alation Website");
            // Dark Theme
      spark.config().setTheme(Theme.STANDARD);
	   
}
	
	
	
	@Test
	public void logintest() throws IOException {
		LoginPage login=new LoginPage(driver,"url");
		logger = extent.createTest("Login To Alation");
		AssertJUnit.assertTrue(login.pageOpen());
		
		
		
	}
	
	@Test(description = "home page after the execution",dependsOnMethods = "logintest")
	public void homepagetest() throws InterruptedException, IOException {
		logger = extent.createTest("To Test Connectors");
	SourcesPage home= new SourcesPage(driver);
	Assert.assertTrue(home.apps_icon_isDisplayed());
	Assert.assertTrue(home.informatica_btn_displayed());
	home.apps_icon_click();
	home.delay(3000);
	home.click_source_btn();
	home.delay(3000);
	home.click_add_btn();
	home.click_data_source();
	home.delay(3000);
	home.input_title("aug 18 test");
	home.continue_setup_btn();
	home.delay(3000);
	home.databasetype();
	home.delay(3000);
	home.filterthelist("informatica");
	home.delay(3000);
	home.informatica_btn();
	Assert.assertTrue(home.informatica_btn_displayed());
	}
	
	@AfterMethod
	public void getResult(ITestResult result) throws Exception{

		if(result.getStatus() == ITestResult.FAILURE) {
        logger.log(Status.FAIL, MarkupHelper.createLabel(result.getName()+" FAILED ", ExtentColor.RED));
        String dest=listener.captureScreenshot();
        logger.addScreenCaptureFromBase64String(dest);
        logger.log(Status.FAIL, MarkupHelper.createLabel("Screenshot Path: "+dest, ExtentColor.BLUE));
        logger.fail(result.getThrowable());
        
    }
    else if(result.getStatus() == ITestResult.SUCCESS) {
        logger.log(Status.PASS, MarkupHelper.createLabel(result.getName()+" PASSED ", ExtentColor.GREEN));
        listener. screenshot();
        
    }
    else {
        logger.log(Status.SKIP, MarkupHelper.createLabel(result.getName()+" SKIPPED ", ExtentColor.ORANGE));
        logger.skip(result.getThrowable());
    }
		
		}
	 
	
	
	
	    
	    @AfterClass
	    public void closeUp()
	    {
	        driver.close();
	        System.out.println("The close_up process is completed");
	    }
	    
	    @AfterTest
	    public void reportReady()
	     {extent.flush();
	     
	        System.out.println("Report is ready to be shared, with screenshots of tests");
	    }
	
	
	   
}
