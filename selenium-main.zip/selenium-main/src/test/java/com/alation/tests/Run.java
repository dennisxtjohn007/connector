package com.alation.tests;

public @interface Run {

}
