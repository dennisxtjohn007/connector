package com.alation.webpages;

import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.io.FileHandler;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Parameters;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.Date;
import java.util.Properties;

import javax.swing.text.Highlighter.Highlight;

import org.apache.log4j.Logger;
import dev.failsafe.internal.util.Assert;
import com.alation.commomutilies.WebEventListener;
import com.alation.commomutilies.Constants;
import com.alation.webpages.SourcesPage;

public class DeployingConnector {
	public static WebDriver driver;
	public static Logger log = Logger.getLogger(DeployingConnector.class);
	// Page URL
	private static String PAGE_URL = Constants.websiteURL;
	public WebEventListener listener;
	// Locators
	@FindBy(tagName = "h4")
	WebElement pageopen;
	@FindBy(name = "email")
	WebElement Alation_username;
	@FindBy(name = "password")
	WebElement Alation_password;
	@FindBy(xpath = "//button[text()='Sign In']")
	WebElement Alation_Login_btn;
	@FindBy(xpath = "//img[contains(@src,'logo_release')]")
	WebElement Alation_img;
	@FindBy(xpath = "//a[@id='admin-top-item']")
	WebElement Setting_gear;
	@FindBy(xpath = "//a[text()='Manage Connectors']")
	WebElement ManageConnector;
	@FindBy(xpath = "//span[text()='Talend']/../../..//span[contains(text(),'Action')]/..")
	WebElement TalendConnector;
	@FindBy(xpath = "//span[text()='Informatica']/../../..//span[contains(text(),'Action')]/..")
	WebElement InformaticaConnector;
	@FindBy(xpath = "//span[text()='Upgrade Connector']/..")
	WebElement UpgradeConnector;
	@FindBy(xpath = "//input[@type='file']")
	WebElement UploadFile;
	@FindBy(xpath = "//button[text()='Install New Connector']")
	WebElement InstallNewConnector;
	@FindBy(xpath = "//h4[text()='Error!']")
	WebElement UploadErrorMsg;
	@FindBy(xpath = "//span[text()='Informatica']/../../..//td[contains(@class,'table-version')]")
	WebElement InformaticaConnectorVersion;
	@FindBy(xpath = "//span[text()='Talend']/../../..//td[contains(@class,'table-version')]")
	WebElement TalendConnectorVersion;
	@FindBy(xpath = "//button[text()='Close']")
	WebElement close;
	public static Properties prop;
	// Constructor

	public DeployingConnector(WebDriver driver, String url) {
		this.driver = driver;
		driver.get(url);
		// Initialise Elements
		PageFactory.initElements(driver, this);
		listener = new WebEventListener(driver);
		// SourcesPage source = new SourcesPage(driver);
	}

	public DeployingConnector() {
		this.driver = driver;
		// Initialize Elements
		PageFactory.initElements(driver, this);
		listener = new WebEventListener(driver);
		// SourcesPage source = new SourcesPage(driver);
	}

	public boolean pageOpen(String url) {
		log.info("verifying the pageisopened or not");
		return pageopen.getText().toString().contains("Type your email and password");
	}

	public boolean Login_to_Alation(String username, String Password) throws IOException {
		boolean teststepstatus = false;
		try {
			log.info("Entering the username");
			listener.highlight(Alation_username);
			Alation_username.sendKeys(username);
			listener.screenshot();
			log.info("Entering the password");
			listener.highlight(Alation_password);
			Alation_password.sendKeys(Password);
			log.info("Clicking the LoginButton");
			listener.highlight(Alation_Login_btn);
			Alation_Login_btn.click();
			listener.screenshot();
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(Constants.DELAY));
			teststepstatus = Alation_img.isDisplayed();
		} catch (Exception e) {
			teststepstatus = false;
		}
		return teststepstatus;
	}

	public boolean deployingNewConnectors(String connectorName, String pathofthefolder) throws IOException {
		listener.highlight(Setting_gear);
		Setting_gear.click();
		listener.screenshot();
		listener.highlight(ManageConnector);
		ManageConnector.click();
		listener.highlight(InstallNewConnector);
		InstallNewConnector.click();
		listener.screenshot();
		listener.highlight(UploadFile);
		UploadFile.sendKeys(pathofthefolder);
		boolean a = !UploadErrorMsg.isDisplayed();
		WebEventListener.screenshot();

		return a;
	}

	public boolean upgradingConnector(String connectorName, String pathofthefolder) throws IOException {
		listener.highlight(Setting_gear);
		Setting_gear.click();
		listener.screenshot();
		listener.highlight(ManageConnector);
		ManageConnector.click();
		if (connectorName.equalsIgnoreCase("Talend")) {
			listener.highlight(TalendConnector);
			TalendConnector.click();
			listener.screenshot();
		} else if (connectorName.equalsIgnoreCase("informatica")) {
			listener.highlight(InformaticaConnector);
			InformaticaConnector.click();
			listener.screenshot();
		}
		listener.highlight(UpgradeConnector);
		UpgradeConnector.click();
		listener.screenshot();
		listener.highlight(UploadFile);
		UploadFile.sendKeys(pathofthefolder);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(Constants.DELAY));
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(Constants.DELAY));
		boolean a = !UploadErrorMsg.isDisplayed();
		listener.screenshot();
        close.click();
		return a;
	}

	public boolean getVersionInfo(String connectorName) throws IOException {
		String versionInfo = null;

		String filePath = System.getProperty("user.dir") + "\\Resources\\selenium.properties";
		if (connectorName.equalsIgnoreCase("Informatica")) {
			FileOutputStream fr = new FileOutputStream(filePath);
			try {
				Properties p = new Properties();
				p.setProperty("informaticaversion", versionInfo);
				p.store(fr, "Version Info");
				System.out.println("Property file is created successfully..");
			} catch (Exception e) {
			}
			fr.close();
		} else if (connectorName.equalsIgnoreCase("Talend")) {
			versionInfo = TalendConnectorVersion.getText();
			FileOutputStream fr = new FileOutputStream(filePath);
			try {
				Properties p = new Properties();
				p.setProperty("talendlatestversion", versionInfo);
				p.store(fr, "Version Info");
				System.out.println("Property file is created successfully..");
			} catch (Exception e) {
			}
			fr.close();

		}
		return false;
	}
}
