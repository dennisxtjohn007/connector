package com.alation.webpages;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.io.FileHandler;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.AfterMethod;

import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.Date;

import javax.swing.text.Highlighter.Highlight;

import org.apache.log4j.Logger;
import dev.failsafe.internal.util.Assert;
import com.alation.commomutilies.WebEventListener;
import com.alation.commomutilies.Constants;
import com.alation.webpages.SourcesPage;
public class LoginPage {
   public static  WebDriver driver;
   public static Logger log = Logger.getLogger(LoginPage.class);
   //Page URL
   private static String PAGE_URL=Constants.websiteURL;
   public WebEventListener listener;
   //Locators
   @FindBy(tagName = "h4")
   WebElement pageopen;
   @FindBy(name = "email")
   WebElement Alation_username;
   @FindBy(name = "password")
   WebElement Alation_password;
   @FindBy(xpath = "//button[text()='Sign In']")
   WebElement Alation_Login_btn;
   @FindBy(xpath = "//img[contains(@src,'logo_release')]")
   WebElement Alation_img;
   @FindBy(xpath = "//span[@class='ui-tooltip']//i[contains(@class,'gears')]")
	WebElement Setting_gear;
	@FindBy(xpath = "//a[text()='Manage Connectors']")
	WebElement ManageConnector;
	@FindBy(xpath = "//span[text()='Talend']/../../..//span[contains(text(),'Action')]/..")
	WebElement TalendConnector;
	@FindBy(xpath = "//span[text()='Informatica']/../../..//span[contains(text(),'Action')]/..")
	WebElement InformaticaConnector;
	@FindBy(xpath = "//span[text()='Upgrade Connector']/..")
	WebElement UpgradeConnector;
	@FindBy(xpath = "//input[@type='file']")
	WebElement UploadFile;
	@FindBy(xpath="//button[text()='Install New Connector']")
   WebElement InstallNewConnector;
   
 //h1[text()="All your data, just a search away"]/..//img
   
   //Constructor
   public LoginPage(WebDriver driver,String url){
       this.driver=driver;
       driver.get(PAGE_URL);
       //Initialise Elements
       PageFactory.initElements(driver, this);
       listener=new WebEventListener(driver);
      
       SourcesPage source=new SourcesPage(driver);
   }
  
  
   public boolean pageOpen(){
	   log.info("verifying the pageisopened or not");
   return pageopen.getText().toString().contains("Type your email and password");
  }
   
   public boolean Login_to_Alation(String username,String Password) throws IOException
   {
	   boolean teststepstatus=false;
	   try {
	   log.info("Entering the username");
	   listener.highlight(Alation_username);
	   Alation_username.sendKeys(username);
	   listener. screenshot();
	   log.info("Entering the password");
       listener.highlight(Alation_password);
	   Alation_password.sendKeys(Password);
	   log.info("Clicking the LoginButton");
       listener.highlight(Alation_Login_btn);
	   Alation_Login_btn.click();
	   listener. screenshot();
	   driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(Constants.DELAY));
	 teststepstatus=  Alation_img.isDisplayed();
	   }
	   catch(Exception e) {
		teststepstatus=false;   
	   }
	   
	   
	return teststepstatus;
	   
   }
   
   
   
}