package com.alation.webpages;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.io.FileHandler;

import com.alation.commomutilies.Constants;
import java.time.LocalTime;
import com.alation.commomutilies.WebEventListener;
import com.alation.commomutilies.normalmethods;
import com.alation.webpages.LoginPage;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.testng.annotations.AfterMethod;

import java.io.File;
import java.io.IOException;
import java.time.Duration;
import java.util.NoSuchElementException;

import org.apache.log4j.Logger;
import dev.failsafe.internal.util.Assert;
public class SourcesPage{

	//locaters
@FindBy(xpath ="//span[text()='Apps']/..//i")
WebElement instance_app_btn;

@FindBy(xpath = "//span[text()='Sources']/parent::a")
WebElement instances_sources_btn;

@FindBy(xpath = "//span[contains(text(),'Add')]/../../..")
WebElement sources_add_btn;
@FindBy(xpath = "//span[text()='Data Source']/..")
WebElement datasources_btn;
@FindBy(xpath = "//input[@placeholder='Title']")
WebElement title_input;
@FindBy(xpath = "//span[@title='DB2']/..")
WebElement databasetype;
@FindBy(xpath = "//button[text()='Continue Setup']")
WebElement continue_setup_btn;
@FindBy(xpath = "//input[@placeholder='Filter this list']")
WebElement filterthelist;
@FindBy(xpath = "//a[text()='Informatica']")
WebElement informatica_btn;
@FindBy(xpath = "//span[text()='Virtual Data Source']/..")
WebElement virtual_data_source_button;
@FindBy(xpath = "//div[@class='catalog-top-btn']//i[@class='ui-icon ficon-ellipsis']")
WebElement ellipsis;

@FindBy(xpath = "//span[normalize-space(text())='Settings']/..']")
WebElement Settings;



@FindBy(xpath ="//a[@title='General Settings']")
WebElement general_settings_tab;

@FindBy(xpath = "//input[@placeholder='Informatica Host']")
static
WebElement Informatica_Host_input;

@FindBy(xpath = "//input[@placeholder='Name']")
static
WebElement Name;
@FindBy(xpath = "//input[@placeholder='Password']")
static
WebElement Password;
@FindBy(xpath = "//input[@placeholder='Folder Name']")
static
WebElement Folder_Name;

@FindBy(xpath = "//h4[text()='Success']")
static
WebElement Success_Message;
@FindBy(xpath = "//a[@title='Metadata Extraction']")
static
WebElement Metadata_Extraction_tab;
@FindBy(xpath = "//button[text()='Run Extraction Now']")
static
WebElement Run_Extaction_btn;
@FindBy(xpath = "//button[text()='Refresh']")
public
static
WebElement Refresh_btn;
@FindBy(xpath = "(//button[text()='Save'])[2]")
static
WebElement Savebutton;
@FindBy(xpath = "//td[@class='col-status']/button")
public
static
WebElement Status;
@FindBy(xpath = "//td[@class='col-message']//p")
static
WebElement Message;


public static Logger log = Logger.getLogger(SourcesPage.class);

public WebDriver driver;
public WebEventListener listener;




public SourcesPage(WebDriver driver) {
	this.driver=driver;
	PageFactory.initElements(driver, this);
	 listener=new WebEventListener(driver);
	 normalmethods b=new normalmethods(driver);
	
}


public boolean AddDataSource(String Title,String dbtype) throws IOException {
	boolean teststepstatus=false;
	try {
	    listener.highlight(instance_app_btn);
	    instance_app_btn.click();
	    driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(Constants.DELAY));
	    listener.highlight(instances_sources_btn);
	    instances_sources_btn.click();
	    driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(Constants.DELAY));
	    listener.highlight(sources_add_btn);
	    sources_add_btn.click();
	    driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(Constants.DELAY));
	    listener.highlight(datasources_btn);
		datasources_btn.click();
		listener. screenshot();
	    driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(Constants.DELAY));
	    listener.highlight(title_input);
		title_input.sendKeys(Title);;
		listener. screenshot();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(Constants.DELAY));
		listener.highlight(continue_setup_btn);
		continue_setup_btn.click();
		listener. screenshot();
	    driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(Constants.DELAY));
	    listener.highlight(databasetype);
		databasetype.click();
		listener. screenshot();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(Constants.DELAY));
		listener.highlight(filterthelist);
		filterthelist.sendKeys(dbtype);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(Constants.DELAY));
		listener.highlight(informatica_btn);
		informatica_btn.click();
		listener. screenshot();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(Constants.DELAY));
		listener. screenshot();
		 teststepstatus=general_settings_tab.isDisplayed();}
	catch(Exception e) {
		teststepstatus=false;
	}
	
	return teststepstatus;
}

public boolean addVirtualDataSource(String Title,String dbtype) {
	boolean teststepstatus=false;
	try {
	    listener.highlight(instance_app_btn);
	    instance_app_btn.click();
	    driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(Constants.DELAY));
	    listener.highlight(instances_sources_btn);
	    instances_sources_btn.click();
	    driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(Constants.DELAY));
	    listener.highlight(sources_add_btn);
	    sources_add_btn.click();
	    driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(Constants.DELAY));
	    listener.highlight(virtual_data_source_button);
	    virtual_data_source_button.click();
		listener. screenshot();
	    driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(Constants.DELAY));
	    listener.highlight(title_input);
		title_input.sendKeys(Title);;
		listener. screenshot();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(Constants.DELAY));
		listener.highlight(continue_setup_btn);
		continue_setup_btn.click();
		listener. screenshot();
	    driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(Constants.DELAY));
	    listener.highlight(databasetype);
		databasetype.click();
		listener. screenshot();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(Constants.DELAY));
		listener.highlight(filterthelist);
		filterthelist.sendKeys(dbtype);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(Constants.DELAY));
		listener.highlight(informatica_btn);
		informatica_btn.click();
		listener. screenshot();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(Constants.DELAY));
		listener. screenshot();
		 teststepstatus=general_settings_tab.isDisplayed();}
	catch(Exception e) {
		teststepstatus=false;
	}
	
	return teststepstatus;
}


public boolean ExtractMetaDataFromExistingDS(String DataSourceName) throws IOException{
	boolean teststepstatus=false;
	try {
		normalmethods b=new normalmethods(driver);
	    listener.highlight(instance_app_btn);
	    instance_app_btn.click();
	    driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(Constants.DELAY));
	    listener.highlight(instances_sources_btn);
	    instances_sources_btn.click();
	    listener. screenshot();
	    driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(Constants.DELAY));
	    listener.highlight(sources_add_btn);
	    sources_add_btn.click();
	    listener. screenshot();
	    driver.findElement(By.xpath("//a[normalize-space(text())='//a[text()='"+DataSourceName+"']']")).click();
	    driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(Constants.DELAY));
	    listener.highlight(ellipsis);
	    ellipsis.click();
	    listener. screenshot();
	    listener.highlight(Settings);
	    Settings.click();
	    driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(Constants.DELAY));
	    Metadata_Extraction_tab.click();
	    driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(Constants.DELAY));
	    Run_Extaction_btn.click();
	    b.waituptoactioncomplete();
	    Status.click();
    }
	catch(Exception e) {
		teststepstatus=false;
	}
	    
	return teststepstatus;
	}






public void configure_metadata_extraction() throws InterruptedException, IOException {
	normalmethods b=new normalmethods(driver);
	listener.highlight(Metadata_Extraction_tab);
	Metadata_Extraction_tab.click();
	delay(3000);
	listener. screenshot();
	Run_Extaction_btn.click();
	listener. screenshot();
	 b.waituptoactioncomplete();
	    Status.click();
}


public void configure_general_settings(String host, String name,String password,String Foldername) throws IOException {
	general_settings_tab.click();
	listener. screenshot();
	listener.highlight(Informatica_Host_input);
	Informatica_Host_input.sendKeys(host);
	listener. screenshot();
	listener.highlight(Name);
	Name.clear();
	Name.sendKeys(name);
	listener. screenshot();
	listener.highlight(Password);
	Password.clear();
	Password.sendKeys(password);
	listener.highlight(Folder_Name);
	listener. screenshot();
	Folder_Name.sendKeys(Foldername);
	listener.highlight(Savebutton);
	Savebutton.click();
	listener. screenshot();
}























public boolean apps_icon_isDisplayed() {
	boolean ele=instance_app_btn.isDisplayed();
	return ele;
}
public void apps_icon_click() throws IOException, InterruptedException {
	 listener.highlight(instance_app_btn);
	instance_app_btn.click();
	listener. screenshot();
	 delay(3000);
}
public static void delay(int wait) throws InterruptedException {
	Thread.sleep(wait);
}

public void click_source_btn() throws IOException, InterruptedException {
	listener.highlight(instances_sources_btn);
	instances_sources_btn.click();
	listener. screenshot();
	 delay(3000);
}
public void click_add_btn() throws IOException, InterruptedException {
	listener.highlight(sources_add_btn);
	sources_add_btn.click();
	listener. screenshot();
	 delay(3000);
	
}
public void click_data_source() throws IOException, InterruptedException {
	listener.highlight(datasources_btn);
	datasources_btn.click();
	listener. screenshot();
	 delay(3000);
}
public void input_title(String title) throws IOException {
	listener.highlight(title_input);
	title_input.sendKeys(title);;
	listener. screenshot();
}
public void databasetype() throws IOException, InterruptedException {
	listener.highlight(databasetype);
	databasetype.click();
	listener. screenshot();
	 delay(3000);
}
public void filterthelist(String text) throws InterruptedException {
	listener.highlight(filterthelist);
	filterthelist.sendKeys(text);
	 delay(3000);
}
public boolean informatica_btn_displayed() {
	boolean ele=informatica_btn.isDisplayed();
	return ele;
}

public void informatica_btn() throws IOException, InterruptedException {
	listener.highlight(informatica_btn);
	informatica_btn.click();
	listener. screenshot();
	 delay(5000);
}
public void continue_setup_btn() throws IOException, InterruptedException {
	listener.highlight(continue_setup_btn);
	continue_setup_btn.click();
	listener. screenshot();
	 delay(3000);
}










	
}
